package com.jor.exception;

public class ShopNotFoundException extends Exception{
    public ShopNotFoundException(String message){
        super(message);
    }
}
