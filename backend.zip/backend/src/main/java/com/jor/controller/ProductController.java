package com.jor.controller;

import com.jor.entity.Product;
import com.jor.exception.ProductNotFoundException;
import com.jor.service.ProductService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@AllArgsConstructor
@RequestMapping("/api/product")
@CrossOrigin("*")
@Tag(name = "Product APIs")
public class ProductController {

    private final ProductService productService;

    @PostMapping(value = "/add-product", consumes = {"multipart/form-data"})
    public ResponseEntity<Product> addProduct(
            @RequestParam("productName") String productName,
            @RequestParam("price") Double price,
            @RequestParam("quantity") Integer quantity,
            @RequestParam("quantityType") String quantityType,
            @RequestParam(value = "file", required = false) MultipartFile file) {

        Product product = new Product();
        product.setProductName(productName);
        product.setPrice(price);
        product.setQuantity(quantity);
        product.setQuantityType(quantityType);

        return ResponseEntity.ok(productService.addProduct(product, file));
    }

    @PutMapping(value = "/update-product", consumes = {"multipart/form-data"})
    public ResponseEntity<Product> updateProduct(
            @RequestParam("productId") Long productId,
            @RequestParam("productName") String productName,
            @RequestParam("price") Double price,
            @RequestParam("quantity") Integer quantity,
            @RequestParam("quantityType") String quantityType,
            @RequestParam(value = "file", required = false) MultipartFile file) {

        Product product = new Product();
        product.setProductId(productId);
        product.setProductName(productName);
        product.setPrice(price);
        product.setQuantity(quantity);
        product.setQuantityType(quantityType);

        return ResponseEntity.ok(productService.updateProduct(product, file));
    }


    @GetMapping("/get-all-products")
    public ResponseEntity<?> getAllProduct() {
        return ResponseEntity.ok(productService.getAllProduct());
    }

    @GetMapping("/get-product-by-id")
    public ResponseEntity<?> getProduct(@RequestParam Long id) throws ProductNotFoundException {
        return ResponseEntity.ok(productService.getProduct(id));
    }

    @DeleteMapping("/delete-product")
    public ResponseEntity<?> deleteProductById(@RequestParam Long id){
        return ResponseEntity.ok(productService.deleteProductById(id));
    }

}
