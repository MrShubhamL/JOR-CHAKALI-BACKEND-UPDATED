package com.jor.controller;

import com.jor.service.DashboardService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/dashboard")
@Tag(name = "Dashboard APIs")
@CrossOrigin("*")
public class DashboardController {

    private final DashboardService dashboardService;


    @GetMapping("/totalStock")
    public ResponseEntity<?> totalStock(){
        return ResponseEntity.ok(dashboardService.getTotalStock());
    }

    @GetMapping("/totalSale")
    public ResponseEntity<?> totalSale(){
        return ResponseEntity.ok(dashboardService.getTotalSale());
    }

    @GetMapping("/totalPendingAmount")
    public ResponseEntity<?> totalPendingAmount(){
        return ResponseEntity.ok(dashboardService.getTotalPending());
    }

    @GetMapping("/totalShops")
    public ResponseEntity<?> totalShops(){
        return ResponseEntity.ok(dashboardService.getTotalShops());
    }

    @GetMapping("/totalOrders")
    public ResponseEntity<?> totalOrders(){
        return ResponseEntity.ok(dashboardService.getTotalOrders());
    }

    @GetMapping("/totalProducts")
    public ResponseEntity<?> totalProducts(){
        return ResponseEntity.ok(dashboardService.getTotalProducts());
    }
}
