package com.jor.controller;

import com.jor.entity.AppUser;
import com.jor.entity.JwtRequest;
import com.jor.entity.JwtResponse;
import com.jor.entity.Role;
import com.jor.jwt.JwtUtils;
import com.jor.repository.AppUserRepository;
import com.jor.repository.RoleRepository;
import com.jor.service.RoleService;
import com.jor.service.impl.jwt.AppUserDetailsServiceImpl;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.*;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/service")
@Tag(name = "Authentication APIs")
@CrossOrigin("*")
public class JwtAuthenticationController {
    private final AppUserDetailsServiceImpl userDetailsService;
    private final AuthenticationManager authenticationManager;
    private final JwtUtils jwtUtils;
    private final AppUserRepository userRepository;
    private final RoleRepository roleRepository;
    private final RoleService roleService;


    @PostConstruct
    public void createAdmin() {
        Optional<AppUser> optionalUser = userRepository.getAppUserByUsername("adminuser@jorchakali.com");
        if (optionalUser.isEmpty()) {
            Role savedRole = roleRepository.findByRoleName("ADMIN")
                    .orElseGet(() -> {
                        Role role = new Role();
                        role.setRoleName("ADMIN");
                        role.setRoleDescription("This is admin role");
                        return roleRepository.save(role);
                    });
            AppUser user = new AppUser();
            user.setName("Head Office");
            user.setUsername("adminuser@jorchakali.com");
            user.setContact("-");
            user.setRole(savedRole);
            user.setPassword(new BCryptPasswordEncoder().encode("jorchakali@2025"));
            userRepository.save(user);
        }
    }

    @PostMapping("/login")
    public JwtResponse createAuthenticationToken(@RequestBody JwtRequest request) {
        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
            );
        } catch (BadCredentialsException e) {
            throw new BadCredentialsException("Incorrect Username or Password.");
        }
        UserDetails userDetails = userDetailsService.loadUserByUsername(request.getUsername());
        System.out.println(userDetails);
        Optional<AppUser> optionalUser = userRepository.getAppUserByUsername(userDetails.getUsername());
        final String jwt = jwtUtils.generateToken(userDetails.getUsername());
        JwtResponse response = new JwtResponse();
        if (optionalUser.isPresent()) {
            response.setJwtToken(jwt);
            Role role= optionalUser.get().getRole();
            response.setRole(role);
            AppUser user = optionalUser.get();
            response.setUsername(user.getUsername());
            return response;
        }
        return null;
    }


    @PostMapping("/is-token-expired")
    public ResponseEntity<?> idTokenExpired(@RequestBody JwtResponse jwtResponse) {
        try {
            return ResponseEntity.status(HttpStatus.OK).body(jwtUtils.isTokenExpired(jwtResponse.getJwtToken()));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.OK).body(true);
        }
    }
}
