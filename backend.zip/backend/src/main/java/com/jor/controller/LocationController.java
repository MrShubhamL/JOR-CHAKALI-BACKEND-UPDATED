package com.jor.controller;

import com.jor.entity.Location;
import com.jor.exception.LocationNotFoundException;
import com.jor.service.LocationService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/location")
@Tag(name = "Location APIs")
@CrossOrigin("*")
public class LocationController {
    private final LocationService locationService;

    @PostMapping("/add-location")
    public ResponseEntity<?> addLocation(@RequestBody Location location){
        return ResponseEntity.ok(locationService.saveLocation(location));
    }

    @PutMapping("/update-location")
    public ResponseEntity<?> updateLocation(@RequestBody Location location){
        return ResponseEntity.ok(locationService.updateLocation(location));
    }

    @GetMapping("/get-location-by-id")
    public ResponseEntity<?> getLocation(@RequestParam Long id) throws LocationNotFoundException {
        return ResponseEntity.ok(locationService.getLocation(id));
    }

    @GetMapping("/get-all-locations")
    public ResponseEntity<?> getLocations(){
        return ResponseEntity.ok(locationService.getLocations());
    }

    @GetMapping("/get-all-locations-order")
    public ResponseEntity<?> getLocationsOrders(){
        return ResponseEntity.ok(locationService.getAllLocationOrders());
    }

    @DeleteMapping("/delete-location")
    public ResponseEntity<?> deleteLocation(@RequestParam Long id) throws LocationNotFoundException {
        System.out.println(id);
        return locationService.deleteLocation(id) ?
                ResponseEntity.ok("Location deleted successfully") :
                ResponseEntity.badRequest().body("Location not deleted");
    }
}
