package com.jor.controller;

import com.jor.entity.ApiResponse;
import com.jor.entity.Product;
import com.jor.entity.Shop;
import com.jor.entity.ShopBill;
import com.jor.exception.ShopNotFoundException;
import com.jor.response.CustomResponse;
import com.jor.service.ShopLocationOrdersService;
import com.jor.service.ShopService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/shop")
@CrossOrigin("*")
@Tag(name = "Shp APIs")
public class ShopController {
    private final ShopService shopService;
    private final ShopLocationOrdersService shopLocationOrdersService;

    @PostMapping("/add-shop")
    public ResponseEntity<?> saveShop(@RequestBody Shop shop){
        return ResponseEntity.ok(shopService.addShop(shop));
    }

    @GetMapping("/get-all-shops")
    public ResponseEntity<?> getShops(){
        return ResponseEntity.ok(shopService.getShops());
    }

    @GetMapping("/get-shop-by-id")
    public ResponseEntity<?> getShop(@RequestParam Long id) throws ShopNotFoundException, ShopNotFoundException {
        return ResponseEntity.ok(shopService.getShop(id));
    }

    @PutMapping("/update-shop")
    public ResponseEntity<?> updateShop(@RequestBody Shop shop) throws ShopNotFoundException, ShopNotFoundException {
        return ResponseEntity.status(HttpStatus.OK).body(shopService.updateShop(shop));
    }

    @DeleteMapping("/delete-shop")
    public ResponseEntity<?> deleteShop(@RequestParam Long id) throws ShopNotFoundException, ShopNotFoundException {
        CustomResponse response = shopService.deleteShop(id);

        if(response.getStatus()){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else{
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @DeleteMapping("/delete-shop-products")
    public ResponseEntity<?> deleteShopProducts(@RequestParam Long id) throws ShopNotFoundException, ShopNotFoundException {
        shopService.deleteShopProductsByShopId(id);
        return ResponseEntity.ok(true);
    }

    @GetMapping("/get-shops-by-location")
    public ResponseEntity<?> findByLocationId(@RequestParam Long id){
        return ResponseEntity.ok(shopService.findShopsByLocation(id));
    }

    @PostMapping("/create-invoice")
    public ResponseEntity<?> createInvoice(@RequestBody List<ShopBill> shopBills){
        return ResponseEntity.ok(shopService.createInvoice(shopBills));
    }

    @GetMapping("/get-shop-details-by-payment-id")
    public ResponseEntity<?> getShopDetailsByPaymentId(@RequestParam Long id){
        return ResponseEntity.ok(shopService.getShopDetailsByPaymentId(id));
    }

    @GetMapping("/get-shop-bill-details-by-invoice-no")
    public ResponseEntity<?> getShopBillDetailsByInvoiceNo(@RequestParam String invoiceNo){
        return ResponseEntity.ok(shopService.getShopBillDetailsByInvoiceNo(invoiceNo));
    }

    @GetMapping("/get-shop-bill-details")
    public ResponseEntity<?> getShopBillDetails(@RequestParam Long shopId){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(shopService.getShopBillDetails(shopId));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/get-all-shop-bill-details")
    public ResponseEntity<?> getAllShopBills(@RequestParam Long id){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(shopService.getAllShopBillsByShopId(id));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        }
    }

    @GetMapping("/get-all-shop-location-orders-by-location")
    public ResponseEntity<?> getAllShopLocationOrders(@RequestParam Long id){
        try {
            return ResponseEntity.status(HttpStatus.OK).body(shopLocationOrdersService.getAllShopLocationOrdersByLocationId(id));
        }catch (Exception e){
            return ResponseEntity.status(HttpStatus.OK).body(e.getMessage());
        }
    }

    @DeleteMapping("/delete-shop-bill")
    public ResponseEntity<?> deleteShopBill(@RequestParam String invoiceNumber){
        ApiResponse response = shopService.deleteShopBill(invoiceNumber);

        if(response.getStatus()){
            return ResponseEntity.status(HttpStatus.OK).body(response);
        }else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    @PutMapping("/update-order-status")
    public ResponseEntity<?> updateOrderStatus(@RequestParam String invoiceNumber, @RequestParam Boolean orderStatus){
       return ResponseEntity.status(HttpStatus.OK).body(shopService.updateOrderStatus(invoiceNumber, orderStatus));
    }

    @PutMapping("/cancel-order-status")
    public ResponseEntity<?> cancelOrderStatus(@RequestParam String invoiceNumber){
        return ResponseEntity.status(HttpStatus.OK).body(shopService.cancelOrderStatus(invoiceNumber));
    }
}
