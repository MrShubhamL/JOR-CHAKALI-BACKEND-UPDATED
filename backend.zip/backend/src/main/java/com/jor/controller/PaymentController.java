package com.jor.controller;

import com.jor.entity.Payments;
import com.jor.service.PaymentService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/payment")
@Tag(name = "Payment APIs")
@CrossOrigin("*")
public class PaymentController {

    private final PaymentService paymentService;

    @PutMapping("/update-payment-details")
    public ResponseEntity<?> updatePaymentDetails(@RequestBody Payments payments){
        return ResponseEntity.status(HttpStatus.OK).body(paymentService.updatePaymentDetails(payments));
    }

    @PutMapping("/update-payment")
    public ResponseEntity<?> updatePayments(@RequestParam Long shopId, @RequestParam Double receivedAmount) {
        paymentService.updatePayments(shopId, receivedAmount);
        return ResponseEntity.ok(true);
    }

    @GetMapping("/get-all-payment-details")
    public ResponseEntity<?> getAllPaymentDetails(){
        return ResponseEntity.status(HttpStatus.OK).body(paymentService.getAllPayments());
    }

    @GetMapping("/get-payment-details-by-invoice-no")
    public ResponseEntity<?> getPaymentDetailsByInvoiceNo(@RequestParam("invoiceNo") String invoiceNo){
        return ResponseEntity.status(HttpStatus.OK).body(paymentService.getPaymentByInvoiceNo(invoiceNo));
    }

    @GetMapping("/get-all-payment-details-by-shop-id")
    public ResponseEntity<?> getAllPaymentDetails(@RequestParam Long id){
        return ResponseEntity.status(HttpStatus.OK).body(paymentService.getAllPaymentsByShopId(id));
    }

    @GetMapping("/get-payment-details-by-paymentId-and-invoiceNo")
    public ResponseEntity<?> getPaymentDetailsByShopId(@RequestParam Long id, @RequestParam String invoiceNo){
        return ResponseEntity.status(HttpStatus.OK).body(paymentService.getPaymentByPaymentId(id));
    }
}
