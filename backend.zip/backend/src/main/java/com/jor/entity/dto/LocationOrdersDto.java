package com.jor.entity.dto;

import com.jor.entity.dto.helper.ShopLocationOrders;
import lombok.Data;

import java.util.List;

@Data
public class LocationOrdersDto {
    private List<ShopLocationOrders> orders;
}
