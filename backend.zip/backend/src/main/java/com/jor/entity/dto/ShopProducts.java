package com.jor.entity.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ShopProducts {
    private Long productId;
    private String productName;
    private Double price;
    private LocalDate date;
    private Integer quantity;
    private String quantityType;
    private String productImage;
}
