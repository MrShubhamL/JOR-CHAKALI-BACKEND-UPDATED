package com.jor.entity.dto.helper;

import com.jor.entity.Product;
import com.jor.entity.dto.ShopProductListDto;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Data
@ToString
public class ShopLocationOrders {
    private String locationName;
    private List<ShopProductListDto> shopProductListDtos;
}
