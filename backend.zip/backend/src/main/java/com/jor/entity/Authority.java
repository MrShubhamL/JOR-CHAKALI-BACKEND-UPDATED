package com.jor.entity;

import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
@Data
public class Authority implements GrantedAuthority {
    private Role authority;
    public Authority() {
        super();
    }

    @Override
    public String getAuthority() {
        return this.authority.getRoleName();
    }

    public void setAuthority(Role authority) {
        this.authority = authority;
    }
}
