package com.jor.entity.dto;

import com.jor.entity.Payments;
import lombok.Data;

import java.util.List;

@Data
public class OrderDto {
    private Boolean orderStatus;
    private List<Payments> payments;
}
