package com.jor.entity.dto;

import com.jor.entity.Product;
import lombok.Data;

import java.util.List;

@Data
public class ShopProductListDto {
    private String productName;
    private Integer quantity;
    private String quantityType;
}
