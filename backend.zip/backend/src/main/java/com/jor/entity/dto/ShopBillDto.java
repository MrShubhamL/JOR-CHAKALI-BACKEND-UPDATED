package com.jor.entity.dto;

import com.jor.entity.Payments;
import com.jor.entity.dto.helper.ShopBillHelper;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ShopBillDto {

    private String invoiceNumber;

    private String customerName;

    private String date;

    private String contactNo;

    private List<ShopBillHelper> shopBillHelpers;
    private List<Payments> payments;
    private Double previousBalance;

}
