package com.jor.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Entity
public class ShopBill {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long shopBillId;

    @ManyToOne
    @JoinColumn(name = "shop_id")
    @JsonBackReference
    private Shop shop;

    private Long productId;
    private Integer quantity;
    private String quantityType;
    private Double rate;
    private Double total;
    private String billDate;
    private String invoiceNumber;
    private Boolean paymentStatus;
    @Transient
    private Double previousBalance;
    private Boolean orderStatus;
    private Long locationId;
}
