package com.jor.entity.dto.helper;

import lombok.Data;

@Data
public class ShopBillLocationOrders {
    private Long productId;
    private String productName;
    private Integer productQuantity;
}
