package com.jor.entity.dto;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.jor.entity.Product;
import com.jor.entity.Shop;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@Entity
public class ShopProductDto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long shopProductDtoId;
    private Long product;
    private Double shopProductPrice;

    @ManyToOne
    @JoinColumn(name = "shop_id")
    @JsonBackReference
    private Shop shop;

}
