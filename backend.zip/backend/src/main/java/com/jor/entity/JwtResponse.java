package com.jor.entity;

import lombok.Data;

@Data
public class JwtResponse {
    private String username;
    private String jwtToken;
    private Role role;
}
