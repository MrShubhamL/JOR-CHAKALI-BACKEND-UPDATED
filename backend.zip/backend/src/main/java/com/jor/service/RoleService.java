package com.jor.service;

import com.jor.entity.Role;
import com.jor.exception.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface RoleService {
    Role createRole(Role role);
    Role updateRole(Role role) throws ResourceNotFoundException;
    Role findById(Long roleId);
}
