package com.jor.service;

import com.jor.entity.ApiResponse;
import com.jor.entity.Shop;
import com.jor.entity.ShopBill;
import com.jor.entity.dto.ShopBillDto;
import com.jor.exception.ResourceNotFoundException;
import com.jor.exception.ShopNotFoundException;
import com.jor.response.CustomResponse;

import java.util.List;

public interface ShopService {
    Shop addShop(Shop shop);
    Shop getShop(Long id) throws ShopNotFoundException;
    List<Shop> getShops();
    Shop updateShop(Shop shop) throws ShopNotFoundException;
    CustomResponse deleteShop(Long id) throws ShopNotFoundException;
    void deleteShopProductsByShopId(Long shopId) throws ShopNotFoundException;

    Shop getShopDetailsByPaymentId(Long id);

    ShopBillDto getShopBillDetailsByInvoiceNo(String invoiceNo);

    List<Shop> findShopsByLocation(Long id);

    List<ShopBill> createInvoice(List<ShopBill> shopBills);
    List<ShopBill> getAllShopBillsByShopId(Long id);

    ShopBillDto getShopBillDetails(Long shopId) throws ResourceNotFoundException;

    ApiResponse deleteShopBill(String invoiceNumber);

    ApiResponse updateOrderStatus(String invoiceNumber, Boolean orderStatus);

    ApiResponse cancelOrderStatus(String invoiceNumber);

}
