package com.jor.service.impl;

import com.jor.entity.Location;
import com.jor.entity.Shop;
import com.jor.entity.ShopBill;
import com.jor.entity.dto.LocationOrdersDto;
import com.jor.entity.dto.helper.ShopLocationOrders;
import com.jor.exception.LocationNotFoundException;
import com.jor.exception.ResourceNotFoundException;
import com.jor.repository.LocationRepository;
import com.jor.repository.ShopBillRepository;
import com.jor.repository.ShopProductDtoRepository;
import com.jor.repository.ShopRepository;
import com.jor.service.LocationService;
import com.jor.service.ShopLocationOrdersService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class LocationServiceImpl implements LocationService {

    private final LocationRepository locationRepository;
    private final ShopRepository shopRepository;
    private final ShopBillRepository shopBillRepository;
    private final ShopProductDtoRepository shopProductDtoRepository;

    private final ShopLocationOrdersService shopLocationOrdersService;

    @Override
    public Location saveLocation(Location location) {
        return locationRepository.save(location);
    }

    @Override
    public Location updateLocation(Location location) {
        return locationRepository.save(location);
    }

    @Override
    public Location getLocation(Long id) throws LocationNotFoundException {
        return locationRepository.findById(id).orElseThrow(
                () -> new LocationNotFoundException("Location not found with id " + id)
        );
    }

    @Override
    public List<Location> getLocations() {
        return locationRepository.findAll();
    }

    @Override
    public Boolean deleteLocation(Long id) throws LocationNotFoundException {
        locationRepository.findById(id).orElseThrow(
                () -> new LocationNotFoundException("Location not found with id " + id)
        );
        locationRepository.deleteById(id);
        return true;
    }

    @Override
    public Boolean updateLocation(Location location, Long id) throws LocationNotFoundException {
        Location oldLocation = locationRepository.findById(id).orElseThrow(
                () -> new LocationNotFoundException("Location not found with id " + id)
        );

        if (location.getLocationName() != null) oldLocation.setLocationName(location.getLocationName());
        locationRepository.save(oldLocation);
        return true;
    }

    @Override
    public LocationOrdersDto getAllLocationOrders() {
        List<Location> locations = locationRepository.findAll();
        List<ShopLocationOrders> orders = new ArrayList<>();
        LocationOrdersDto locationOrdersDto = new LocationOrdersDto();
        locations.forEach(l -> {
            ShopLocationOrders shopLocationOrders = null;

            shopLocationOrders = shopLocationOrdersService.getAllShopLocationOrdersByLocationId(l.getLocationId());

            orders.add(shopLocationOrders);
            locationOrdersDto.setOrders(orders);
        });
        return locationOrdersDto;
    }
}
