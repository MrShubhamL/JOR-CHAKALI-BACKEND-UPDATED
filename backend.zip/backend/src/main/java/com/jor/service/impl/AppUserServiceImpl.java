package com.jor.service.impl;

import com.jor.entity.AppUser;
import com.jor.repository.AppUserRepository;
import com.jor.service.AppUserService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class AppUserServiceImpl implements AppUserService {

    private final AppUserRepository userRepository;

    @Override
    public boolean getAppUserByUserName(String userName) {
        return userRepository.getAppUserByUsername(userName).isPresent();
    }

    @Override
    public AppUser getAppUserByUserNameInfo(String userName) {
        return null;
    }

    @Override
    public AppUser registerUser(AppUser user) {
        return userRepository.save(user);
    }

    @Override
    public AppUser updateUser(AppUser myUser) {
        return null;
    }
}
