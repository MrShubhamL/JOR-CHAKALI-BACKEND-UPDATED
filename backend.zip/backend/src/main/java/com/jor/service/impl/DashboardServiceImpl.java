package com.jor.service.impl;

import com.jor.repository.*;
import com.jor.service.DashboardService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class DashboardServiceImpl implements DashboardService {

    private final ShopRepository shopRepository;
    private final ShopBillRepository shopBillRepository;
    private final PaymentRepository paymentRepository;
    private final LocationRepository locationRepository;
    private final ProductRepository productRepository;
    private final ShopProductDtoRepository shopProductDtoRepository;


    @Override
    public Double getTotalStock() {
        return productRepository.getTotalProductQuantity().get();
    }

    @Override
    public Double getTotalSale() {
        return shopBillRepository.getTotalSale().get();
    }

    @Override
    public Double getTotalPending() {
        return paymentRepository.getTotalPendingAmount().get();
    }

    @Override
    public Double getTotalShops() {
        return shopRepository.getTotalShops().get();
    }

    @Override
    public Double getTotalOrders() {
        return shopBillRepository.getTotalOrders().get();
    }

    @Override
    public Double getTotalProducts() {
        return productRepository.getTotalProducts().get();
    }
}
