package com.jor.service;

import org.springframework.stereotype.Service;

@Service
public interface DashboardService {

    Double getTotalStock();
    Double getTotalSale();
    Double getTotalPending();
    Double getTotalShops();
    Double getTotalOrders();
    Double getTotalProducts();
}
