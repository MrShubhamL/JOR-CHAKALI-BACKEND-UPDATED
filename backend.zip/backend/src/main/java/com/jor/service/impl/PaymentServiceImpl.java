package com.jor.service.impl;

import com.jor.entity.Payments;
import com.jor.entity.ShopBill;
import com.jor.entity.dto.OrderDto;
import com.jor.repository.PaymentRepository;
import com.jor.repository.ShopBillRepository;
import com.jor.service.PaymentService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {

    private final PaymentRepository paymentRepository;
    private final ShopBillRepository shopBillRepository;

    @Override
    public Payments updatePaymentDetails(Payments payments) {
        Payments existedPaymentDetails=paymentRepository.getByShopShopId(payments.getShop().getShopId());
        existedPaymentDetails.setPendingAmount(existedPaymentDetails.getPendingAmount()-payments.getReceivedAmount());
        existedPaymentDetails.setPaidAmount(existedPaymentDetails.getPaidAmount()+payments.getReceivedAmount());
        existedPaymentDetails.setTotalAmount(existedPaymentDetails.getPendingAmount()+existedPaymentDetails.getPaidAmount());
        List<Payments> existedAllPaymentsByShop = paymentRepository.getPaymentsByShopShopId(existedPaymentDetails.getShop().getShopId());
        for(Payments p:existedAllPaymentsByShop){
            p.setTotalPendingAmount(p.getTotalPendingAmount()-payments.getReceivedAmount());
            paymentRepository.save(p);
        }
        shopBillRepository.getAllShopBillByInvoiceNumber(payments.getInvoiceNumber())
                .forEach(shopBill -> {
                    shopBill.setPaymentStatus(true);
                    shopBillRepository.save(shopBill);
                });
        existedPaymentDetails.setPaymentStatus(existedPaymentDetails.getPendingAmount() == 0);
        return paymentRepository.save(existedPaymentDetails);
    }


    @Override
    @Transactional
    public void updatePayments(Long shopId, Double receivedAmount) {
        List<Payments> payments = paymentRepository.findByShopShopIdOrderByPaymentIdAsc(shopId);

        double remainingAmount = receivedAmount;

        for (Payments payment : payments) {
            if (remainingAmount <= 0) break;

            if (payment.getPendingAmount() > 0) {
                double deduction = Math.min(payment.getPendingAmount(), remainingAmount);
                payment.setPaidAmount(payment.getPaidAmount() + deduction);
                payment.setPendingAmount(payment.getPendingAmount() - deduction);

                // Mark payment as completed if fully paid
                if (payment.getPendingAmount() == 0) {
                    payment.setPaymentStatus(true);
                }

                remainingAmount -= deduction;
            }
        }

        // Recalculate total pending amount
        double totalPendingAmount = payments.stream().mapToDouble(Payments::getPendingAmount).sum();

        // Update total pending amount in all records
        for (Payments payment : payments) {
            payment.setTotalPendingAmount(totalPendingAmount);
        }

        paymentRepository.saveAll(payments);
    }

    @Override
    public Payments getPaymentByInvoiceNo(String invoiceNo) {
        return paymentRepository.getPaymentsByInvoiceNumber(invoiceNo);
    }

    @Override
    public List<Payments> getAllPayments() {
        return paymentRepository.findAll();
    }

    @Override
    public List<Payments> getAllPaymentsByShopId(Long id) {
        return paymentRepository.getPaymentsByShopShopId(id);
    }

    @Override
    public Payments getPaymentByPaymentId(Long id) {
        return paymentRepository.getPaymentsByPaymentId(id);
    }
}