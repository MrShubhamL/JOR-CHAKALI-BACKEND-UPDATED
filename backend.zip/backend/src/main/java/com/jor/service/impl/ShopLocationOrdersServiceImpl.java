package com.jor.service.impl;

import com.jor.entity.dto.ShopProductListDto;
import com.jor.entity.dto.helper.ShopLocationOrders;
import com.jor.repository.*;
import com.jor.service.ShopLocationOrdersService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
@RequiredArgsConstructor
public class ShopLocationOrdersServiceImpl implements ShopLocationOrdersService {
    private final ShopRepository shopRepository;
    private final ShopBillRepository shopBillRepository;
    private final ProductRepository productRepository;
    private final LocationRepository locationRepository;

    @Override
    public ShopLocationOrders getAllShopLocationOrdersByLocationId(Long id) {
        ShopLocationOrders shopLocationOrders = new ShopLocationOrders();
        shopLocationOrders.setLocationName(locationRepository.findById(id).get().getLocationName());

        Map<Long, ShopProductListDto> productMap = new HashMap<>();

        shopBillRepository.getShopBillByOrderStatusAndLocationId(false, id)
                .forEach(shopBill -> {
                    Long productId = shopBill.getProductId();
                    if (productMap.containsKey(productId)) {
                        ShopProductListDto existingProduct = productMap.get(productId);
                        existingProduct.setQuantity(existingProduct.getQuantity() + shopBill.getQuantity());
                    } else {
                        ShopProductListDto newProduct = new ShopProductListDto();
                        newProduct.setQuantity(shopBill.getQuantity());
                        newProduct.setProductName(productRepository.getProductsByProductId(productId).getProductName());
                        newProduct.setQuantityType(shopBill.getQuantityType());
                        productMap.put(productId, newProduct);
                    }
                });
        shopLocationOrders.setShopProductListDtos(new ArrayList<>(productMap.values()));
        return shopLocationOrders;
    }


}
