package com.jor.service.impl;

import com.jor.entity.Product;
import com.jor.exception.ProductNotFoundException;
import com.jor.repository.ProductRepository;
import com.jor.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.DeleteObjectResponse;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;

    private final S3Client s3Client;

    @Value("${app.s3.bucket}")
    private String bucketName;

    @Override
    public Product addProduct(Product product, MultipartFile image) {

        String originalFilename = image.getOriginalFilename();
        String fileName = UUID.randomUUID().toString() + originalFilename.substring(originalFilename.lastIndexOf("."));

        try {
            // Upload file to S3
            PutObjectResponse putObjectResponse = s3Client.putObject(
                    PutObjectRequest.builder()
                            .bucket(bucketName)
                            .key(fileName)
                            .build(),
                    RequestBody.fromBytes(image.getBytes())
            );

            // Store S3 image URL in product entity
            String imageUrl = "https://" + bucketName + ".s3.amazonaws.com/" + fileName;
            product.setProductImage(imageUrl);

            product.setDate(LocalDate.now());
            return productRepository.save(product);

        } catch (IOException e) {
            throw new RuntimeException("Error uploading file to S3", e);
        }
    }

    @Override
    public Product updateProduct(Product product, MultipartFile image) {
        try {
            Product productsByProductId = productRepository.getProductsByProductId(product.getProductId());
            String existingImageUrl = productsByProductId.getProductImage();

            if (image != null && !image.isEmpty()) {
                String fileName = existingImageUrl != null && !existingImageUrl.isEmpty()
                        ? existingImageUrl.substring(existingImageUrl.lastIndexOf("/") + 1)
                        : UUID.randomUUID().toString();

                System.out.println(fileName);

                s3Client.putObject(
                        PutObjectRequest.builder()
                                .bucket(bucketName)
                                .key(fileName)
                                .build(),
                        RequestBody.fromBytes(image.getBytes())
                );

                String imageUrl = "https://" + bucketName + ".s3.amazonaws.com/" + fileName;
                product.setProductImage(imageUrl);  // Update product image URL
            } else {
                product.setProductImage(existingImageUrl);
            }

            product.setDate(LocalDate.now());

            return productRepository.save(product);
//                return null;
        } catch (IOException e) {
            throw new RuntimeException("Error uploading file to S3", e);
        }
    }


    @Override
    public List<Product> getAllProduct() {
        return productRepository.findAll();
    }

    @Override
    public Product getProduct(Long id) throws ProductNotFoundException {
        return productRepository.findById(id).orElseThrow(
                () -> new ProductNotFoundException("Product not found with id " + id)
        );
    }

    @Override
    public Boolean deleteProductById(Long id) {
        // Find the product in the database
        Optional<Product> optionalProduct = productRepository.findById(id);

        if (optionalProduct.isPresent()) {
            Product product = optionalProduct.get();

            // Extract the image URL
            String imageUrl = product.getProductImage();

            if (imageUrl != null && !imageUrl.isEmpty()) {
                // Extract file name from the image URL
                String fileName = imageUrl.substring(imageUrl.lastIndexOf("/") + 1);

                // Delete the image from S3
                try {
                    DeleteObjectResponse deleteResponse = s3Client.deleteObject(
                            DeleteObjectRequest.builder()
                                    .bucket(bucketName)
                                    .key(fileName)
                                    .build()
                    );
                } catch (Exception e) {
                    throw new RuntimeException("Error deleting image from S3", e);
                }
            }

            // Delete product from the database
            productRepository.deleteById(id);
            return true;
        }

        return false; // Return false if product is not found
    }

}
