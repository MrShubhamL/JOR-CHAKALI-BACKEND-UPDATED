package com.jor.service;

import com.jor.entity.AppUser;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public interface AppUserService {
    boolean getAppUserByUserName(String userName);
    AppUser getAppUserByUserNameInfo(String userName);
    AppUser registerUser(AppUser user);
    AppUser updateUser(AppUser myUser);

}
