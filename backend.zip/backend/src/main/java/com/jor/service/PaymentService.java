package com.jor.service;

import com.jor.entity.Payments;
import com.jor.entity.dto.OrderDto;

import java.util.List;

public interface PaymentService {

    Payments updatePaymentDetails(Payments payments);

    List<Payments> getAllPayments();
    List<Payments> getAllPaymentsByShopId(Long id);

    Payments getPaymentByPaymentId(Long id);

    void updatePayments(Long shopId, Double receivedAmount);

    Payments getPaymentByInvoiceNo(String invoiceNo);
}
