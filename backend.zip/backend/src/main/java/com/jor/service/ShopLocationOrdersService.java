package com.jor.service;

import com.jor.entity.dto.helper.ShopLocationOrders;
import org.springframework.stereotype.Service;

@Service
public interface ShopLocationOrdersService {
    ShopLocationOrders getAllShopLocationOrdersByLocationId(Long id);
}
