package com.jor.service.impl;

import com.jor.entity.*;
import com.jor.entity.dto.ShopBillDto;
import com.jor.entity.dto.ShopProductDto;
import com.jor.entity.dto.helper.ShopBillHelper;
import com.jor.exception.ResourceNotFoundException;
import com.jor.exception.ShopNotFoundException;
import com.jor.repository.*;
import com.jor.response.CustomResponse;
import com.jor.service.ShopService;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

@Service
@RequiredArgsConstructor
public class ShopServiceImpl implements ShopService {
    private final ShopRepository shopRepository;
    private final ShopBillRepository shopBillRepository;
    private final ShopProductDtoRepository shopProductDtoRepository;
    private final ProductRepository productRepository;
    private final PaymentRepository paymentRepository;

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Shop addShop(Shop shop) {
        if (shop.getShopProductDtos() != null) {
            for (ShopProductDto productDto : shop.getShopProductDtos()) {
                productDto.setShop(shop);
            }
        }
        return shopRepository.save(shop);
    }


    @Override
    public Shop getShop(Long id) throws ShopNotFoundException {
        return shopRepository.findById(id).orElseThrow(
                () -> new ShopNotFoundException("Shop not found with id " + id)
        );
    }

    @Override
    public List<Shop> getShops() {
        return shopRepository.findAll();
    }

    @Override
    public Shop updateShop(Shop shop) throws ShopNotFoundException {
        Shop existedShop = shopRepository.findById(shop.getShopId()).orElseThrow(
                () -> new ShopNotFoundException("Shop not found with id " + shop.getShopId())
        );
        existedShop.setShopName(shop.getShopName());
        existedShop.setLocation(shop.getLocation());
        existedShop.setContact(shop.getContact());

        shopProductDtoRepository.deleteByShopId(existedShop.getShopId());
        if (shop.getShopProductDtos() != null && !shop.getShopProductDtos().isEmpty()) {
            existedShop.setShopProductDtos(shop.getShopProductDtos());
        } else {
            existedShop.setShopProductDtos(existedShop.getShopProductDtos());
        }
        return shopRepository.save(existedShop);
    }


    @Override
    public CustomResponse deleteShop(Long id) throws ShopNotFoundException {
        Optional<Shop> optionalShop = shopRepository.findById(id);

        if (optionalShop.isPresent()) {

            shopRepository.delete(optionalShop.get());
            return new CustomResponse(true, "Shop deleted", null);

        } else {
            return new CustomResponse(false, "Shop not deleted", null);
        }
    }

    @Override
    public void deleteShopProductsByShopId(Long shopId) {
        shopRepository.deleteByShopId(shopId);
    }

    @Override
    public Shop getShopDetailsByPaymentId(Long id) {
        return shopRepository.getShopByPaymentsPaymentId(id);
    }

    @Override
    public ShopBillDto getShopBillDetailsByInvoiceNo(String invoiceNo) {
        ShopBill shopBillByInvoiceNumber = shopBillRepository.getShopBillByInvoiceNumber(invoiceNo);

        ShopBillDto shopBillDto = new ShopBillDto();
        List<ShopBillHelper> shopBillHelpers = new ArrayList<>();

        Long shopId = shopBillByInvoiceNumber.getShopBillId();

        ShopBillHelper shopBillHelper = new ShopBillHelper();
        shopBillDto.setInvoiceNumber(shopBillByInvoiceNumber.getInvoiceNumber());
        shopBillDto.setCustomerName(shopBillByInvoiceNumber.getShop().getShopName());
        shopBillDto.setDate(shopBillByInvoiceNumber.getBillDate());
        shopBillDto.setContactNo(shopBillByInvoiceNumber.getShop().getContact());

        Optional<Product> productById = productRepository.findById(shopBillByInvoiceNumber.getProductId());
        productById.ifPresent(product -> shopBillHelper.setProductName(product.getProductName()));

        shopBillHelper.setRate(shopBillByInvoiceNumber.getRate());
        shopBillHelper.setAmount(shopBillByInvoiceNumber.getTotal());
        shopBillHelper.setQuantity(shopBillByInvoiceNumber.getQuantity());
        shopBillHelper.setQuantityType(shopBillByInvoiceNumber.getQuantityType());
        shopBillHelpers.add(shopBillHelper);

//        Payments paymentsByInvoiceNumber = paymentRepository.getPaymentsByInvoiceNumber(invoiceNo);
        List<Payments> previousPayments = paymentRepository.findAllExcludingInvoice(invoiceNo);

        double previousBalance = 0.0;
        for (Payments p : previousPayments) {
            previousBalance += p.getPendingAmount();
        }

        shopBillDto.setPreviousBalance(previousBalance);
        shopBillDto.setShopBillHelpers(shopBillHelpers);

        return shopBillDto;
    }



    @Override
    public List<Shop> findShopsByLocation(Long id) {
        return shopRepository.findByLocation_LocationId(id);
    }

    @Override
    @Transactional
    public List<ShopBill> createInvoice(List<ShopBill> shopBills) {
        List<ShopBill> shopBillList = new ArrayList<>();

        String invoiceNumber = generateInvoiceNumber();

        shopBills.forEach(shopBill -> {
            Product product = productRepository.findById(shopBill.getProductId()).orElseThrow(
                    () -> new RuntimeException("Product not found with ID: " + shopBill.getProductId()));

            if (shopBill.getQuantity() > product.getQuantity()) {
                throw new RuntimeException("Insufficient stock for product ID: " + shopBill.getProductId());
            }

            Shop shop = shopRepository.findById(shopBill.getShop().getShopId()).orElseThrow(
                    () -> new RuntimeException("Shop not found with ID: " + shopBill.getShop().getShopId()));

            ShopProductDto shopProductDto = shopProductDtoRepository.findByProductIdAndShop(shopBill.getProductId(), shop).get();

            ShopBill sb = new ShopBill();
            sb.setRate(shopProductDto.getShopProductPrice());
            sb.setProductId(product.getProductId());
            sb.setInvoiceNumber(invoiceNumber);
            sb.setQuantity(shopBill.getQuantity());
            sb.setQuantityType(product.getQuantityType());
            sb.setTotal(shopProductDto.getShopProductPrice() * shopBill.getQuantity());
            sb.setShop(shopBill.getShop());
            sb.setBillDate(LocalDate.now().toString());
            sb.setPaymentStatus(false);
            sb.setOrderStatus(false);
            sb.setLocationId(shop.getLocation().getLocationId());
            ShopBill savedShopBill = shopBillRepository.save(sb);
            shopBillList.add(savedShopBill);

            product.setQuantity(product.getQuantity() - shopBill.getQuantity());
            productRepository.save(product);
        });
        ShopBill shopBill = shopBillList.stream().findFirst().get();
        Shop shop = shopRepository.findById(shopBill.getShop().getShopId()).get();
        Payments payments = new Payments();
        payments.setShop(shop);
        payments.setInvoiceNumber(invoiceNumber);
        payments.setPaidAmount(0.0);
        payments.setOrderStatus(false);
        payments.setReceivedAmount(0.0);
        Double pendingAmount = 0.0;
        for (ShopBill sh : shopBillList) {
            System.out.println("TOTAL: " + sh.getTotal());
            pendingAmount += sh.getTotal();
        }
        payments.setPendingAmount(pendingAmount);
        payments.setTotalAmount(shopBill.getTotal());
        payments.setPaymentStatus(false);

        List<Payments> existedPaymentsByShop = paymentRepository.getPaymentsByShopShopId(shop.getShopId());

        double totalPendingAmount = 0.0;
        if (existedPaymentsByShop != null) {
            if (!existedPaymentsByShop.isEmpty()) {
                for (Payments p : existedPaymentsByShop) {
                    totalPendingAmount += p.getPendingAmount();
                }
                payments.setTotalPendingAmount(totalPendingAmount + pendingAmount);

                for (Payments p2 : existedPaymentsByShop) {
                    p2.setTotalPendingAmount(totalPendingAmount + pendingAmount);
                    paymentRepository.save(p2);
                }
            } else {
                payments.setTotalPendingAmount(pendingAmount);
            }
        }

        paymentRepository.save(payments);
        return shopBillList;
    }

    @Override
    public List<ShopBill> getAllShopBillsByShopId(Long id) {
        return shopBillRepository.getShopBillByShopShopId(id);
    }

    private String generateInvoiceNumber() {
        String datePart = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));

        Optional<ShopBill> lastBill = shopBillRepository.findTopByInvoiceNumberStartingWithOrderByInvoiceNumberDesc("INV-" + datePart);

        if (lastBill.isPresent()) {
            String lastInvoice = lastBill.get().getInvoiceNumber();
            int lastSequence = Integer.parseInt(lastInvoice.substring(lastInvoice.lastIndexOf("-") + 1));
            return "INV-" + datePart + "-" + String.format("%04d", lastSequence + 1);
        } else {
            return "INV-" + datePart + "-0001";
        }
    }

    @Override
    public ShopBillDto getShopBillDetails(Long shopId) throws ResourceNotFoundException {
        Shop shop = shopRepository.findById(shopId)
                .orElseThrow(() -> new ResourceNotFoundException("Shop not found with id " + shopId));

        ShopBillDto shopBillDto = new ShopBillDto();

        shopBillDto.setCustomerName(shop.getShopName());
        shopBillDto.setContactNo(shop.getContact());

        List<ShopBillHelper> shopBillHelpers = new ArrayList<>();
        shop.getShopBills()
                .forEach(shopBill -> {
                    ShopBillHelper shopBillHelper = new ShopBillHelper();
                    Product product = productRepository.findById(shopBill.getProductId()).get();
                    shopBillHelper.setProductName(product.getProductName());
                    shopBillHelper.setQuantity(shopBill.getQuantity());
                    shopBillHelper.setRate(shopBill.getRate());
                    shopBillHelper.setAmount(shopBill.getQuantity() * shopBill.getRate());
                    shopBillHelpers.add(shopBillHelper);
                    shopBillDto.setInvoiceNumber(shopBill.getInvoiceNumber());
                    shopBillDto.setDate(shopBill.getBillDate());
                });
        List<Payments> paymentByShopShopId = paymentRepository.getPaymentByShopShopId(shopId);
        shopBillDto.setShopBillHelpers(shopBillHelpers);
        shopBillDto.setPayments(paymentByShopShopId);
        return shopBillDto;
    }

    @Override
    public ApiResponse deleteShopBill(String invoiceNumber) {
        List<ShopBill> allShopBills = shopBillRepository.getUnpaidShopBillByInvoiceNumber(invoiceNumber);

        if (!allShopBills.isEmpty()) {

            allShopBills.forEach(shopBill -> {
                Product existedProduct = productRepository.findById(shopBill.getProductId()).get();
                existedProduct.setQuantity(existedProduct.getQuantity() + shopBill.getQuantity());
                productRepository.save(existedProduct);
            });
            shopBillRepository.deleteAll(allShopBills);

//            Payments existedPayment = paymentRepository.getPaymentByShopShopId(shopb);
//            List<Payments> allPayments = paymentRepository.getPaymentsByShopShopId(existedPayment.getShop().getShopId());
//
//            allPayments.forEach(p->{
//                p.setTotalPendingAmount(p.getTotalPendingAmount()-existedPayment.getPendingAmount());
//                paymentRepository.save(p);
//            });
//
//            paymentRepository.delete(existedPayment);
            return new ApiResponse(true, "Deleted!");
        } else {
            return new ApiResponse(false, "Not Deleted!");
        }
    }

    @Override
    public ApiResponse updateOrderStatus(String invoiceNumber, Boolean orderStatus) {
        ShopBill shopBillByInvoiceNumber = shopBillRepository.getShopBillByInvoiceNumber(invoiceNumber);
        Payments paymentsByInvoiceNumber = paymentRepository.getPaymentsByInvoiceNumber(invoiceNumber);
        paymentsByInvoiceNumber.setOrderStatus(orderStatus);
        shopBillByInvoiceNumber.setOrderStatus(orderStatus);
        paymentRepository.save(paymentsByInvoiceNumber);
        shopBillRepository.save(shopBillByInvoiceNumber);
        return new ApiResponse(true, "Status updated!");
    }

    @Override
    public ApiResponse cancelOrderStatus(String invoiceNumber) {
        ShopBill shopBillByInvoiceNumber = shopBillRepository.getShopBillByInvoiceNumber(invoiceNumber);
        shopBillByInvoiceNumber.setOrderStatus(false);
        shopBillRepository.save(shopBillByInvoiceNumber);
        return new ApiResponse(true, "Order cancelled!");
    }

}
