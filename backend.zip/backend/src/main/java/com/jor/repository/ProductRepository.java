package com.jor.repository;

import com.jor.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    Product getProductsByProductId(Long id);

    @Query("SELECT SUM(p.quantity) FROM Product p")
    Optional<Double> getTotalProductQuantity();

    @Query("SELECT COUNT(p.productId) FROM Product p")
    Optional<Double> getTotalProducts();
}
