package com.jor.repository;

import com.jor.entity.Payments;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payments, Long> {

    Payments getByShopShopId(Long shopId);
    Payments getPaymentsByPaymentId(Long id);
    Payments getPaymentsByInvoiceNumber(String invoiceNo);
    List<Payments> getPaymentByShopShopId(Long id);
    List<Payments> getPaymentsByShopShopId(Long Id);

    @Transactional
    @Modifying
    void deleteByShopShopId(Long id);

    @Query("SELECT SUM(p.pendingAmount) FROM Payments p")
    Optional<Double> getTotalPendingAmount();

//    Payments findByShopShopIdAndPaymentIdNot(Long shopId, Long paymentId);

    @Query("""
       SELECT p 
       FROM Payments p 
       WHERE p.shop.shopId = :shopId 
       AND p.paymentId < (SELECT MAX(p2.paymentId) 
                          FROM Payments p2 
                          WHERE p2.shop.shopId = :shopId)
       """)
    List<Payments> findAllPreviousPayments(@Param("shopId") Long shopId);

    List<Payments> findByShop_ShopIdAndPaymentIdNot(Long shopId, Long paymentId);
    List<Payments> findByInvoiceNumberAndPaymentIdNot(String invoiceNumber, Long paymentId);

    @Query("""
       SELECT p FROM Payments p WHERE p.invoiceNumber != :invoiceNumber
       """)
    List<Payments> findAllExcludingInvoice(@Param("invoiceNumber") String invoiceNumber);


    List<Payments> findByShopShopIdOrderByPaymentIdAsc(Long shopId);


}
