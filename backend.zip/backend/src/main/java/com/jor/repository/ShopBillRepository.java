package com.jor.repository;

import com.jor.entity.ShopBill;
import com.jor.entity.dto.ShopBillDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ShopBillRepository extends JpaRepository<ShopBill, Long> {
    Optional<ShopBill> findTopByInvoiceNumberStartingWithOrderByInvoiceNumberDesc(String datePrefix);
    @Query("SELECT s FROM ShopBill s WHERE s.invoiceNumber = :invoiceNo")
    ShopBill getShopBillByInvoiceNumber(@Param("invoiceNo") String invoiceNo);

    @Query("SELECT s FROM ShopBill s WHERE s.invoiceNumber = :invoiceNo")
    List<ShopBill> getAllShopBillByInvoiceNumber(@Param("invoiceNo") String invoiceNo);

    @Query("SELECT s FROM ShopBill s WHERE s.invoiceNumber = :invoiceNo AND s.paymentStatus = false AND s.orderStatus=false")
    List<ShopBill> getUnpaidShopBillByInvoiceNumber(@Param("invoiceNo") String invoiceNo);


    List<ShopBill> getShopBillByShopShopId(Long id);


    List<ShopBill> getShopBillByOrderStatusAndLocationId(Boolean orderStatus, Long id);


    @Query("SELECT SUM(b.total) FROM ShopBill b")
    Optional<Double> getTotalSale();

    @Query("SELECT count(b.shopBillId) FROM ShopBill b WHERE b.orderStatus = true")
    Optional<Double> getTotalOrders();
}
