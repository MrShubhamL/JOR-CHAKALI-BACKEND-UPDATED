package com.jor.repository;

import com.jor.entity.Shop;
import com.jor.entity.dto.ShopProductDto;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ShopProductDtoRepository extends JpaRepository<ShopProductDto, Long> {
    @Modifying
    @Transactional
    @Query("DELETE FROM ShopProductDto sp WHERE sp.shop.shopId = :shopId")
    void deleteByShopId(@Param("shopId") Long shopId);

    List<ShopProductDto> findByShopProductDtoId(Long shopId);
    List<ShopProductDto> findShopProductDtoByShopShopId(Long shopId);

    @Query("SELECT sp FROM ShopProductDto sp WHERE sp.product = :productId AND sp.shop = :shop")
    Optional<ShopProductDto> findByProductIdAndShop(@Param("productId") Long productId, @Param("shop") Shop shop);
}
