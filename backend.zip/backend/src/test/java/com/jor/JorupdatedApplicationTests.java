package com.jor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JorupdatedApplicationTests {

	@Test
	void contextLoads() {
	}

}
