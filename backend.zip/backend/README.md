spring.application.name=jorsnacks
#logging.level.root=ERROR


spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://localhost:3306/jorDB
spring.datasource.username=root
spring.datasource.password=root

#spring.datasource.url=jdbc:mysql://localhost:3306/jorchak9_jorDB
#spring.datasource.username=jorchak9_jor_user
#spring.datasource.password=JorChakali@2025


spring.jpa.hibernate.ddl-auto=update

#spring.jpa.show-sql=true
#spring.jpa.properties.hibernate.format_sql=true
springdoc.swagger-ui.path=/dev


spring.servlet.multipart.enabled=true
spring.servlet.multipart.max-file-size=50MB
spring.servlet.multipart.max-request-size=50MB
spring.servlet.multipart.file-size-threshold=50MB


# AWS Configuration
cloud.aws.credentials.access-key=AKIAWX2IFK4UL4NKDCEA
cloud.aws.credentials.secret-key=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
cloud.aws.region.static=ap-south-1
app.s3.bucket=jorchakalibucket
aws.java.v1.disableDeprecationAnnouncement=true
